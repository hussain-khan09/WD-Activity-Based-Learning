# Hearth & Hand

## Overview

A static storefront-style webpage with navigation, search presentation, promotional banners, and eight product cards showing prices, ratings, and discounts.

## Features

- Store navigation
- Search interface presentation
- Promotional banners
- Eight product cards
- Prices, ratings, and discount labels
- Responsive layout using Flexbox and CSS Grid

## Technology

- HTML5
- CSS3
- Flexbox
- CSS Grid
- Responsive CSS

## Getting Started

1. Keep the HTML, CSS, and any image assets in the project's original folder structure.
2. Open the main HTML file in a modern web browser.
3. Resize the browser window to check the responsive layout.

The original filenames were not available in the current context. A typical structure might look like this:

```text
project/
├── index.html
├── styles.css
└── images/
```

Use the actual filenames and paths from your project rather than assuming these example names.

## Limitations

- This is a static front-end page.
- Search, cart, checkout, and account actions are not connected to a backend unless implemented separately.
- Product content and prices are static unless a data layer is added.

## Customization

- Edit HTML to change headings, text, product details, and page sections.
- Edit CSS to change colors, typography, spacing, and layout.
- Recheck links, responsive behavior, and accessibility after changes.

## License

No license information was provided. Add a license if you plan to distribute the project.
