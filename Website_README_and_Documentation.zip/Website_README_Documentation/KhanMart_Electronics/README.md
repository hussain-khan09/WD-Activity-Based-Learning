# KhanMart Electronics

## Overview

A navy-themed electronics storefront built with HTML and CSS, featuring product categories, product cards, and a comparison table.

## Features

- Navy-themed styling
- Categories: Laptops, Smartphones, Accessories, and Smart Devices
- Products: Zenith Air 14, Pixelo X5, Nova S Ultra, Pixelo Buds Pro, and Pixelo Watch 2
- Product comparison table
- Responsive layout
- Static links and buttons

## Technology

- HTML5
- CSS3
- Responsive CSS
- CSS layout techniques

## Getting Started

1. Keep the HTML, CSS, and any image assets in the project's original folder structure.
2. Open the main HTML file in a modern web browser.
3. Resize the browser window to check the responsive layout.

The original filenames were not available in the current context. A typical structure might look like this:

```text
project/
├── index.html
├── styles.css
└── images/
```

Use the actual filenames and paths from your project rather than assuming these example names.

## Limitations

- This is a static front-end storefront.
- Links and buttons do not imply a working checkout or order-processing system.
- Inventory, live pricing, payments, and authentication are not connected to a backend unless implemented separately.

## Customization

- Edit HTML to change headings, text, product details, and page sections.
- Edit CSS to change colors, typography, spacing, and layout.
- Recheck links, responsive behavior, and accessibility after changes.

## License

No license information was provided. Add a license if you plan to distribute the project.
